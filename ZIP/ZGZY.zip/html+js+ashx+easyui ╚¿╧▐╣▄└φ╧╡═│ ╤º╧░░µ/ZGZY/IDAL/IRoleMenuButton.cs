﻿using System.Collections.Generic;

namespace ZGZY.IDAL
{
    /// <summary>
    /// 角色菜单按钮接口（不同的数据库访问类实现接口达到多数据库的支持）
    /// </summary>
    public interface IRoleMenuButton
    {


    }
}
