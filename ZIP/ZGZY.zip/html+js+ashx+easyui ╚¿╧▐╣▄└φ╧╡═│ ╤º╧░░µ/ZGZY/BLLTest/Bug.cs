﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZGZY.BLLTest
{
    public class Bug
    {
        //...

    }
}
