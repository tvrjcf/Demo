﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZGZY.BLL
{
    /// <summary>
    /// BUG（BLL）
    /// </summary>
    public class Bug
    {
        //private static readonly ZGZY.IDAL.IBug dal = ZGZY.DALFactory.Factory.GetBugDAL();

    }
}
