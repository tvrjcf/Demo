﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZGZY.BLL
{
    /// <summary>
    /// 角色菜单按钮（BLL）
    /// </summary>
    public class RoleMenuButton
    {
        //private static readonly ZGZY.IDAL.IRoleMenuButton dal = ZGZY.DALFactory.Factory.GetRoleMenuButtonDAL();


    }
}
