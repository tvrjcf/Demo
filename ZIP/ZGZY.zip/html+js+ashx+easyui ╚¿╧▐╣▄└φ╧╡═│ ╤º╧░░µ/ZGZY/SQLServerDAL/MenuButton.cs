﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ZGZY.SQLServerDAL
{
    /// <summary>
    /// 菜单按钮（SQL Server数据库实现）
    /// </summary>
    public class MenuButton
    {


    }
}
