﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tank
{
    /// <summary>
    /// UDLR分别表是上下左右4个方向
    /// </summary>
    public  enum directions
    {
        U,D,L,R
    };
}
