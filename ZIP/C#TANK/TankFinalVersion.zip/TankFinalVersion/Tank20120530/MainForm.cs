﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using Tank20120530.Properties;
using System.Collections;

namespace Tank20120530
{
    public partial class MainForm : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
        public static extern short GetAsyncKeyState(int keyCode);

        //我的坦克和地方坦克的速度，生命，子弹速度
        private static int myTankSpeed = 5;
        private static int enemyTankSpeed = 1;
        private static int myTankLife = 10;
        private static int enemyLife = 1;
        private static int myTankBulletSpeed = 15;
        private static int enemyTankBulletSpeed = 15;

        //我的坦克
        private MyTank myTank = new MyTank(myTankBornPositionX, myTankBornPositionY, myTankLife, myTankSpeed, Direction.Up);

        //游戏中老鹰的位置
        private Boss boss = new Boss(myTankWidth * 6, screenHeight - 1 * myTankWidth);

        //游戏界面的宽度和高度
        private static int screenWidth = 390;
        private static int screenHeight = 390;

        //我方坦克和地方坦克的高度和宽度
        private static int myTankHeight = 30;
        private static int myTankWidth = 30;
        private static int enemyTankHeight = 28;
        private static int enemyTankWidth = 28;

        //敌方坦克数量上限
        private static int enemyTankMaxNum = 5;

        //我方坦克出生的位置
        private static int myTankBornPositionX = 120;
        private static int myTankBornPositionY = 360;
        private static int enemyTankBornPositonX = 0;
        private static int enemyTankBornPositonY = 0;

        //我的坦克子弹链表，敌方坦克子弹链表，敌方坦克链表,墙链表
        List<Bullet> myTankBullet = new List<Bullet>();
        List<Bullet> enemyTankBullet = new List<Bullet>();
        List<EnemyTank> enemyTank = new List<EnemyTank>();
        List<Wall> wall = new List<Wall>();
        List<Steel> steel = new List<Steel>();

        //游戏图片绘制在bmp上来显示到窗体上
        private Bitmap bmp = null;
        private Graphics g = null;

        private Graphics gBorn = null;

        //创建线程用于刷新屏幕
        private Thread threadRefresh = null;

        //这里假设我方坦克和敌方坦克的速度会出现不同的情况，因此分别定义一个线程，方便深化以后修改

        //我方坦克的子弹线程
        //private Thread threadMyTankBullet = null;

        //地方坦克的子弹线程
        //private Thread threadEnemyTankBullet = null;

        //敌方坦克线程，用于检测是否要生成敌方坦克,以及敌方坦克移动的方法
        //因为，我方坦克只有一个，而且是走动控制移动，因此就不添加线程了。
        private Thread threadEnemyTank = null;

        //全局线程是否已经开启
        private bool isRun = true;

        //记录开场时候的坦克图片出现前的闪烁效果
        private int myTakBornPictureIndex = 1;
        private int enemyTankBornPictureIndex = 1;
        private int produceEnemyBulletCounter = 0;

        private int runMyTankCounter = 0;
        private int runMyTankBulletCounter = 0;
        private int runEnemyTankBulletCounter = 0;
        private int runMapCounter = 0;

        //敌方坦克出现间隔20计时器
        private int enemyshowTimeIntervalCounter = 20;

        //由于本游戏设计时线程10毫秒刷新一次，太快。按键响应不需要这么快，不然玩家坦克，在按下一次空格键后
        private int checkButtonDownTime = 0;


        public MainForm()
        {
            // this.MaximumSize = this.MinimumSize = new Size(450, 450);
            InitializeComponent();

            //初始化地图
            IntialMap();

            //双缓冲的一些设置
            bmp = new Bitmap(screenWidth, screenHeight);
            g = Graphics.FromImage(bmp);
            g.Clear(Color.Black);

            //设置双缓冲画图
            this.DoubleBuffered = true;
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);
        }

        //原来底层重绘每次会清除画布，然后再全部重新绘制，这才是导致闪烁最主要的原因
        protected override void WndProc(ref Message m)
        {
            // 禁掉清除背景消息
            if (m.Msg == 0x0014)
                return;
            base.WndProc(ref m);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //开启刷新页面线程
            threadRefresh = new Thread(new ThreadStart(RefreshUI));
            threadRefresh.Priority = ThreadPriority.Highest;
            threadRefresh.Start();
            threadRefresh.IsBackground = true;

            ////我方坦克的子弹移动线程
            //threadMyTankBullet = new Thread(new ThreadStart(MyTankBulletMethod));
            //threadMyTankBullet.Start();
            //threadMyTankBullet.IsBackground = true;

            ////敌方坦克的子弹移动线程
            //threadEnemyTankBullet = new Thread(new ThreadStart(EnemyTankBulletMethod));
            //threadEnemyTankBullet.Start();
            //threadEnemyTankBullet.IsBackground = true;

            //敌方坦克线程
            threadEnemyTank = new Thread(new ThreadStart(EnemyTankMethod));
            threadEnemyTank.Priority = ThreadPriority.BelowNormal;
            threadEnemyTank.Start();
            threadEnemyTank.IsBackground = true;

        }

        /// <summary>
        /// 画墙的代码
        /// </summary>
        private void IntialMap()
        {
            #region 最上部分墙
            for (int width = myTankWidth; width < screenWidth - myTankWidth; width += myTankWidth * 2)
            {
                if ((width != myTankWidth * 5))
                {
                    if ((width != myTankWidth * 7))
                        for (int height = myTankWidth; height < myTankWidth * 5; height += Resources.wall.Width)
                        {
                            Wall tempWall = new Wall(width, height);
                            wall.Add(tempWall);
                            tempWall = new Wall(width + Resources.wall.Width, height);
                            wall.Add(tempWall);
                        }
                }
                else
                {
                    for (int height = myTankWidth; height < myTankWidth * 4; height += Resources.wall.Width)
                    {
                        Wall tempWall = new Wall(width, height);
                        wall.Add(tempWall);
                        tempWall = new Wall(width + Resources.wall.Width, height);
                        wall.Add(tempWall);
                    }

                    for (int height = myTankWidth * 5; height < myTankWidth * 6; height += Resources.wall.Width)
                    {
                        Wall tempWall = new Wall(width, height);
                        wall.Add(tempWall);
                        tempWall = new Wall(width + Resources.wall.Width, height);
                        wall.Add(tempWall);
                    }

                }
                if (width == myTankWidth * 7)
                {
                    for (int height = myTankWidth; height < myTankWidth * 4; height += Resources.wall.Width)
                    {
                        Wall tempWall = new Wall(width, height);
                        wall.Add(tempWall);
                        tempWall = new Wall(width + Resources.wall.Width, height);
                        wall.Add(tempWall);
                    }

                    for (int height = myTankWidth * 5; height < myTankWidth * 6; height += Resources.wall.Width)
                    {
                        Wall tempWall = new Wall(width, height);
                        wall.Add(tempWall);
                        tempWall = new Wall(width + Resources.wall.Width, height);
                        wall.Add(tempWall);
                    }
                }
            }
            #endregion

            #region 最下部分墙
            for (int width = myTankWidth; width < screenWidth - myTankWidth; width += myTankWidth * 2)
                for (int height = screenHeight - 5 * myTankWidth; height < screenHeight - 1 * myTankWidth; height += Resources.wall.Width)
                {
                    if (width == myTankWidth * 5 || width == myTankWidth * 7)
                    {
                        if (height >= screenHeight - 3 * myTankWidth + Resources.wall.Width)
                            continue;
                    }

                    Wall tempWall = new Wall(width, height);
                    wall.Add(tempWall);
                    tempWall = new Wall(width + Resources.wall.Width, height);
                    wall.Add(tempWall);

                    if (width == myTankWidth * 5)
                    {
                        for (int j = screenHeight - 6 * myTankWidth; j < screenHeight - 5 * myTankWidth; j += Resources.wall.Width)
                        {
                            Wall temWall = new Wall(width, j);
                            wall.Add(temWall);
                            temWall = new Wall(width + Resources.wall.Width, j);
                            wall.Add(temWall);
                        }
                    }
                    if (width == myTankWidth * 7)
                    {

                        Wall tWall = new Wall(width - myTankWidth, screenHeight - 6 * myTankWidth + Resources.wall.Width);
                        wall.Add(tWall);
                        tWall = new Wall(width - myTankWidth + Resources.wall.Width, screenHeight - 6 * myTankWidth + Resources.wall.Width);
                        wall.Add(tWall);
                        tWall = new Wall(width - myTankWidth, screenHeight - 5 * myTankWidth);
                        wall.Add(tWall);
                        tWall = new Wall(width - myTankWidth + Resources.wall.Width, screenHeight - 5 * myTankWidth);
                        wall.Add(tWall);

                        for (int j = screenHeight - 6 * myTankWidth; j < screenHeight - 5 * myTankWidth; j += Resources.wall.Width)
                        {
                            Wall temWall = new Wall(width, j);
                            wall.Add(temWall);
                            temWall = new Wall(width + Resources.wall.Width, j);
                            wall.Add(temWall);
                        }
                    }
                }
            #endregion

            #region 中间部分墙
            for (int width = myTankWidth * 2; width < myTankWidth * 4; width += Resources.wall.Width)
                for (int height = 6 * myTankWidth; height < 7 * myTankWidth; height += Resources.wall.Width)
                {
                    Wall tempWall = new Wall(width, height);
                    wall.Add(tempWall);
                }

            for (int width = screenWidth - myTankWidth * 4; width < screenWidth - myTankWidth * 2; width += Resources.wall.Width)
                for (int height = 6 * myTankWidth; height < 7 * myTankWidth; height += Resources.wall.Width)
                {
                    Wall tempWall = new Wall(width, height);
                    wall.Add(tempWall);
                }
            #endregion

            #region 画出 老鹰的位置
            //左边
            Wall tepWall = new Wall(myTankWidth * 5 + Resources.wall.Width, screenHeight - 1 * myTankWidth - Resources.wall.Width);
            wall.Add(tepWall);
            tepWall = new Wall(myTankWidth * 5 + Resources.wall.Width, screenHeight - 1 * myTankWidth);
            wall.Add(tepWall);
            tepWall = new Wall(myTankWidth * 5 + Resources.wall.Width, screenHeight - 1 * myTankWidth + Resources.wall.Width);
            wall.Add(tepWall);

            //右边
            tepWall = new Wall(myTankWidth * 7, screenHeight - 1 * myTankWidth - Resources.wall.Width);
            wall.Add(tepWall);
            tepWall = new Wall(myTankWidth * 7, screenHeight - 1 * myTankWidth);
            wall.Add(tepWall);
            tepWall = new Wall(myTankWidth * 7, screenHeight - 1 * myTankWidth + Resources.wall.Width);
            wall.Add(tepWall);

            //中间
            tepWall = new Wall(myTankWidth * 6, screenHeight - 1 * myTankWidth - Resources.wall.Width);
            wall.Add(tepWall);
            tepWall = new Wall(myTankWidth * 6 + Resources.wall.Width, screenHeight - 1 * myTankWidth - Resources.wall.Width);
            wall.Add(tepWall);

            #endregion

            #region 画出钢铁的位置
            //左边
            Steel tempSteel = new Steel(0, 6 * myTankWidth + Resources.wall.Width);
            steel.Add(tempSteel);
            tempSteel = new Steel(Resources.wall.Width, 6 * myTankWidth + Resources.wall.Width);
            steel.Add(tempSteel);
            //右边
            tempSteel = new Steel(screenWidth - Resources.wall.Width, 6 * myTankWidth + Resources.wall.Width);
            steel.Add(tempSteel);
            tempSteel = new Steel(screenWidth - 2 * Resources.wall.Width, 6 * myTankWidth + Resources.wall.Width);
            steel.Add(tempSteel);
            //中间四块
            tempSteel = new Steel(6 * myTankWidth, 3 * myTankWidth - Resources.wall.Width);
            steel.Add(tempSteel);
            tempSteel = new Steel(6 * myTankWidth + Resources.wall.Width, 3 * myTankWidth - Resources.wall.Width);
            steel.Add(tempSteel);
            tempSteel = new Steel(6 * myTankWidth + Resources.wall.Width, 3 * myTankWidth);
            steel.Add(tempSteel);
            tempSteel = new Steel(6 * myTankWidth, 3 * myTankWidth);
            steel.Add(tempSteel);
            #endregion

        }

        private void RefreshUI()
        {
            while (isRun)
            {
                runMyTankCounter++;
                runMyTankBulletCounter++;
                runEnemyTankBulletCounter++;
                runMapCounter++;
                checkButtonDownTime++;
                //if (checkCounter % 10 == 0)
                {
                    //子弹的碰撞检测
                    IsBulletHit();
                }

                // if (runMyTankCounter % 10 == 0)
                {
                    if (myTank != null)
                    {
                        //检测键盘按键又没有按下，控制我方坦克移动
                        IsKeyDown();
                    }
                    else
                    {
                        int index = myTakBornPictureIndex / 2 + 1;
                        if (index <= 3)
                        {
                            DrawBorn(myTankBornPositionX, myTankBornPositionY, index);
                            myTakBornPictureIndex++;
                        }
                        else
                        {
                            myTakBornPictureIndex = 1;
                            myTank = new MyTank(myTankBornPositionX, myTankBornPositionY, myTankLife, myTankSpeed, Direction.Up);
                        }
                    }
                }

                //if (runMyTankBulletCounter % 1 == 0)
                {
                    MyTankBulletMethod();
                }
                //if (runEnemyTankBulletCounter % 1 == 0)
                {
                    EnemyTankBulletMethod();
                }

                //if (runMapCounter % 10 == 0)
                {
                    //画我的坦克，敌方坦克，我的子弹，敌方子弹
                    g.Clear(Color.Black);
                    DrawMyTankBullet(g);
                    DrawEnemyTankBullet(g);
                    DrawMyTank(g);
                    DrawEnemyTank(g);
                    DrawWall(g);

                    //显示图像
                    DrawMap();
                }
                Thread.Sleep(10);
            }
        }

        //此处参照张老师的代码，来响应按键
        private void IsKeyDown()
        {
            //坦克在玩家按下按键是否能走，需要判断是否和墙相撞，是否和敌方坦克相撞

            //赋值给临时变量，因为坦克移动是多线程的，防止线程冲突
            List<EnemyTank> tempEnemyTank = new List<EnemyTank>();
            foreach (EnemyTank temp in enemyTank)
            {
                tempEnemyTank.Add(temp);
            }

            List<Wall> tempWall = new List<Wall>();
            foreach (Wall temp in wall)
            {
                tempWall.Add(temp);
            }

            MyTank tempMyTank = new MyTank(myTankBornPositionX, myTankBornPositionY, myTankLife, myTankSpeed, Direction.Up); ;
            tempMyTank = myTank;

            List<Steel> tempSteel = new List<Steel>();
            foreach (Steel temp in steel)
            {
                tempSteel.Add(temp);
            }

            bool keyDown = false;
            keyDown = (((ushort)GetAsyncKeyState((int)Keys.Down)) & 0xffff) != 0;
            if (keyDown == true)
            {
                tempMyTank.Move(tempWall, tempSteel, tempMyTank, tempEnemyTank, myTankWidth, myTankHeight, Direction.Down);
            }

            bool keyUp = false;
            if (keyDown == false)
            {
                keyUp = (((ushort)GetAsyncKeyState((int)Keys.Up)) & 0xffff) != 0;
                if (keyUp == true)
                {
                    tempMyTank.Move(tempWall, tempSteel, tempMyTank, tempEnemyTank, myTankWidth, myTankHeight, Direction.Up);
                }
            }

            bool keyLeft = false;
            if (keyDown == false && keyUp == false)
            {
                keyLeft = (((ushort)GetAsyncKeyState((int)Keys.Left)) & 0xffff) != 0;
                if (keyLeft == true)
                {
                    tempMyTank.Move(tempWall, tempSteel, tempMyTank, tempEnemyTank, myTankWidth, myTankHeight, Direction.Left);
                }
            }

            bool keyRight = false;
            if (keyDown == false && keyUp == false && keyLeft == false)
            {
                keyRight = (((ushort)GetAsyncKeyState((int)Keys.Right)) & 0xffff) != 0;
                if (keyRight == true)
                {
                    tempMyTank.Move(tempWall, tempSteel, tempMyTank, tempEnemyTank, myTankWidth, myTankHeight, Direction.Right);
                }
            }

            if(checkButtonDownTime %3 ==1)
            {
            bool keySpace = (((ushort)GetAsyncKeyState((int)Keys.Space)) & 0xffff) != 0;
            if (keySpace == true)
            {
                if (myTank.Dir == Direction.Up)
                {
                    Bullet tempBullet = new Bullet(tempMyTank.X + 2, tempMyTank.Y - 4, myTankBulletSpeed, tempMyTank.Dir, BulletType.MyBullet);
                    myTankBullet.Add(tempBullet);
                }
                else if (myTank.Dir == Direction.Down)
                {
                    Bullet tempBullet = new Bullet(tempMyTank.X + 5, tempMyTank.Y + 13, myTankBulletSpeed, tempMyTank.Dir, BulletType.MyBullet);
                    myTankBullet.Add(tempBullet);
                }
                else if (myTank.Dir == Direction.Left)
                {
                    Bullet tempBullet = new Bullet(tempMyTank.X - 5, myTank.Y + 5, myTankBulletSpeed, tempMyTank.Dir, BulletType.MyBullet);
                    myTankBullet.Add(tempBullet);
                }
                else
                {
                    Bullet tempBullet = new Bullet(tempMyTank.X + 13, myTank.Y + 2, myTankBulletSpeed, tempMyTank.Dir, BulletType.MyBullet);
                    myTankBullet.Add(tempBullet);
                }
            }
            }
            myTank = tempMyTank;
        }

        //子弹的碰撞检测
        private void IsBulletHit()
        {
            //这里需要重新定义一个临时的变量用于检测，因为游戏是多线程的，如果不暂时替换的话，那么
            //当其他元素运动之后就会造成线程互斥

            //我的坦克子弹链表，敌方坦克子弹链表，敌方坦克链表,墙链表,钢铁链表
            List<Bullet> tempMyTankBullet = new List<Bullet>();

            foreach (Bullet temp in myTankBullet)
            {
                tempMyTankBullet.Add(temp);
            }
            List<Bullet> tempEnemyTankBullet = new List<Bullet>();
            foreach (Bullet temp in enemyTankBullet)
            {
                tempEnemyTankBullet.Add(temp);
            }
            List<EnemyTank> tempEnemyTank = new List<EnemyTank>();
            foreach (EnemyTank temp in enemyTank)
            {
                tempEnemyTank.Add(temp);
            }
            List<Wall> tempWall = new List<Wall>();
            foreach (Wall temp in wall)
            {
                tempWall.Add(temp);
            }
            List<Steel> tempSteel = new List<Steel>();
            foreach (Steel temp in steel)
            {
                tempSteel.Add(temp);
            }

            MyTank tempMyTank = new MyTank(myTankBornPositionX, myTankBornPositionY, myTankLife, myTankSpeed, Direction.Up);
            tempMyTank = myTank;

            #region 检测我方子弹和钢铁碰撞
            if (tempMyTankBullet.Count != 0)
            {
                int removeMyBulletCount = 0;
                for (int i = 0; i < tempMyTankBullet.Count; i++)
                {

                    for (int j = 0; j < tempSteel.Count; j++)
                    {
                        if (tempMyTankBullet[i].GetRectangle().IntersectsWith(tempSteel[j].GetRectangle()))
                        {
                            //创建爆炸线程
                            ArrayList num = new ArrayList(2);
                            num.Add(tempMyTankBullet[i].X);
                            num.Add(tempMyTankBullet[i].Y);
                            Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                            threadBlast.Start(num);
                            threadBlast.IsBackground = true;
                            myTankBullet.RemoveAt(i - removeMyBulletCount);
                            removeMyBulletCount++;
                            break;
                        }
                    }
                }
            }
            #endregion

            //因为，我方子弹和钢铁的碰撞检测执行后，我方子弹数量可能发生变化，因此重新赋值
            tempMyTankBullet.Clear();
            foreach (Bullet temp in myTankBullet)
            {
                tempMyTankBullet.Add(temp);
            }

            #region 检测敌方子弹和钢铁的碰撞
            if (tempEnemyTankBullet.Count != 0)
            {
                int removeEnemyTankBulletCount = 0;
                for (int i = 0; i < tempEnemyTankBullet.Count; i++)
                {
                    for (int j = 0; j < tempSteel.Count; j++)
                    {
                        if (tempEnemyTankBullet[i].GetRectangle().IntersectsWith(tempSteel[j].GetRectangle()))
                        {
                            //创建爆炸线程
                            ArrayList num = new ArrayList(2);
                            num.Add(tempEnemyTankBullet[i].X);
                            num.Add(tempEnemyTankBullet[i].Y);
                            Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                            threadBlast.Start(num);
                            threadBlast.IsBackground = true;
                            enemyTankBullet.RemoveAt(i - removeEnemyTankBulletCount);
                            removeEnemyTankBulletCount++;
                            break;
                        }
                    }
                }
            }
            #endregion

            //tempEnemyTankBullet需要重新赋值，因为上面的检测可能导致 enemyTankBullet的变化
            tempEnemyTankBullet.Clear();
            foreach (Bullet temp in enemyTankBullet)
            {
                tempEnemyTankBullet.Add(temp);
            }

            #region 检测我方子弹和boss的碰撞，如果碰撞那么宣布游戏结束
            for (int i = 0; i < tempMyTankBullet.Count; i++)
            {
                if (tempMyTankBullet[i].GetRectangle().IntersectsWith(boss.GetRectangle()))
                {
                    //游戏结束
                    DrawGameOver(g);
                }
            }
            #endregion

            #region 检测敌方子弹和boss的碰撞，如果碰撞那么宣布游戏结束
            for (int i = 0; i < tempEnemyTankBullet.Count; i++)
            {
                if (tempEnemyTankBullet[i].GetRectangle().IntersectsWith(boss.GetRectangle()))
                {
                    //游戏结束
                    DrawGameOver(g);
                }
            }
            #endregion

            #region 检测我方子弹和墙的碰撞
            //如果我方坦克的子弹不等于0，和墙进行碰撞检测
            if (tempMyTankBullet.Count != 0)
            {
                int removeWallCount = 0;
                int removeMyBulletCount = 0;
                for (int i = 0; i < tempMyTankBullet.Count; i++)
                {
                    if (myTankBullet.Count != 0)
                    {
                        bool canRemoveMyBullet = true;
                        for (int j = 0; j < tempWall.Count; j++)
                        {
                            try
                            {
                                if (tempMyTankBullet[i].GetRectangle().IntersectsWith(tempWall[j].GetRectangle()))
                                {
                                    if (wall.Count != 0)
                                    {

                                        //移除碰撞的子弹和墙
                                        wall.RemoveAt(j - removeWallCount);
                                        removeWallCount++;
                                        if (canRemoveMyBullet == true)
                                        {
                                            //创建爆炸线程
                                            ArrayList num = new ArrayList(2);
                                            num.Add(tempWall[j].X);
                                            num.Add(tempWall[j].Y);
                                            Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                                            threadBlast.Start(num);
                                            threadBlast.IsBackground = true;
                                            //while (!threadBlast.IsAlive) ;
                                            canRemoveMyBullet = false;
                                            myTankBullet.RemoveAt(i - removeMyBulletCount);
                                            removeMyBulletCount++;
                                        }

                                    }
                                }
                            }
                            catch { }
                        }
                    }
                }
            }
            #endregion

            //因为，我方子弹和墙的碰撞检测执行后，我方子弹数量可能发生变化，因此重新赋值
            tempMyTankBullet.Clear();
            foreach (Bullet temp in myTankBullet)
            {
                tempMyTankBullet.Add(temp);
            }

            #region 检查我方子弹和敌方坦克碰撞
            //如果我方坦克的子弹不等于0，和敌方坦克进行碰撞检测
            if (tempMyTankBullet.Count != 0)
            {
                int removeEnemyTankCount = 0;
                int removeMyTankBullet = 0;
                for (int i = 0; i < tempMyTankBullet.Count; i++)
                {
                    if (myTankBullet.Count != 0)
                    {
                        bool canRemoveMyTankBullet = true;
                        for (int j = 0; j < tempEnemyTank.Count; j++)
                        {
                            if (tempMyTankBullet[i].GetRectangle().IntersectsWith(tempEnemyTank[j].GetRectangle()))
                            {
                                if (enemyTank.Count != 0)
                                {
                                    //创建爆炸线程
                                    ArrayList num = new ArrayList(2);
                                    num.Add(tempEnemyTank[j].X);
                                    num.Add(tempEnemyTank[j].Y);
                                    Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                                    threadBlast.Start(num);
                                    threadBlast.IsBackground = true;
                                    //while (!threadBlast.IsAlive) ;

                                    //移除碰撞的子弹和敌方坦克
                                    if (j - removeEnemyTankCount >= 0)
                                    {
                                        if (enemyTank[j - removeEnemyTankCount].Life == 1)
                                        {
                                            enemyTank.RemoveAt(j - removeEnemyTankCount);
                                            removeEnemyTankCount++;
                                        }
                                        else
                                        {
                                            enemyTank[j - removeEnemyTankCount].Life--;
                                        }
                                    }
                                    else
                                    {
                                        myTankBullet.RemoveAt(i - removeMyTankBullet);
                                        canRemoveMyTankBullet = false;
                                    }
                                    if (canRemoveMyTankBullet == true)
                                    {
                                        canRemoveMyTankBullet = false;
                                        myTankBullet.RemoveAt(i - removeMyTankBullet);
                                        removeMyTankBullet++;
                                    }

                                }
                            }
                        }
                    }
                }
            }
            #endregion

            //因为，我方子弹和敌方坦克的碰撞检测执行后，我方子弹数量可能发生变化，因此重新赋值
            tempMyTankBullet.Clear();
            foreach (Bullet temp in myTankBullet)
            {
                tempMyTankBullet.Add(temp);
            }

            #region 我方子弹和敌方子弹碰撞
            //如果我方坦克的子弹不等于0，和敌方子弹进行碰撞检测
            if (tempMyTankBullet.Count != 0)
            {
                int removetempEnemyTankBulletCount = 0;
                int removeMyTankBullet = 0;
                for (int i = 0; i < tempMyTankBullet.Count; i++)
                {
                    if (myTankBullet.Count != 0)
                    {
                        bool canRemoveMyTankBullet = true;
                        for (int j = 0; j < tempEnemyTankBullet.Count; j++)
                        {
                            if (tempMyTankBullet[i].GetRectangle().IntersectsWith(tempEnemyTankBullet[j].GetRectangle()))
                            {
                                if (enemyTankBullet.Count != 0)
                                {
                                    //创建爆炸线程
                                    ArrayList num = new ArrayList(2);
                                    num.Add(tempEnemyTankBullet[j].X);
                                    num.Add(tempEnemyTankBullet[j].Y);
                                    Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                                    threadBlast.Start(num);
                                    threadBlast.IsBackground = true;
                                    // while (!threadBlast.IsAlive) ;

                                    //移除碰撞的子弹
                                    if (j - removetempEnemyTankBulletCount >= 0)
                                    {
                                        enemyTankBullet.RemoveAt(j - removetempEnemyTankBulletCount);
                                        if (canRemoveMyTankBullet == true)
                                        {
                                            canRemoveMyTankBullet = false;
                                            myTankBullet.RemoveAt(i - removeMyTankBullet);
                                            removeMyTankBullet++;
                                        }
                                        removetempEnemyTankBulletCount++;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            #endregion

            //墙需要重新赋值，因为上面的检测可能导致墙的变化
            tempWall.Clear();
            foreach (Wall temp in wall)
            {
                tempWall.Add(temp);
            }

            #region 敌方坦克和墙的碰撞
            //如果敌方坦克的子弹不等于0,和墙进行碰撞检测
            if (tempEnemyTankBullet.Count != 0)
            {
                int removeWallCount = 0;
                int removeEnemyTankBulletCount = 0;
                for (int i = 0; i < tempEnemyTankBullet.Count; i++)
                {
                    if (enemyTankBullet.Count != 0)
                    {
                        bool canRemoveEnemyTankBullet = true;
                        for (int j = 0; j < tempWall.Count; j++)
                        {
                            if (tempEnemyTankBullet[i].GetRectangle().IntersectsWith(tempWall[j].GetRectangle()))
                            {
                                if (wall.Count != 0)
                                {
                                    //创建爆炸线程
                                    ArrayList num = new ArrayList(2);
                                    num.Add(tempWall[j].X);
                                    num.Add(tempWall[j].Y);
                                    Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                                    threadBlast.Start(num);
                                    threadBlast.IsBackground = true;
                                    // while (!threadBlast.IsAlive) ;

                                    //移除碰撞的子弹和墙
                                    wall.RemoveAt(j - removeWallCount);
                                    if (canRemoveEnemyTankBullet == true)
                                    {
                                        canRemoveEnemyTankBullet = false;
                                        enemyTankBullet.RemoveAt(i - removeEnemyTankBulletCount);
                                        removeEnemyTankBulletCount++;
                                    }
                                    removeWallCount++;
                                }
                            }
                        }
                    }
                }
            }
            #endregion

            //tempEnemyTankBullet需要重新赋值，因为上面的检测可能导致 enemyTankBullet的变化
            tempEnemyTankBullet.Clear();
            try
            {
                foreach (Bullet temp in enemyTankBullet)
                {
                    tempEnemyTankBullet.Add(temp);
                }
            }
            catch
            { }
            tempMyTank = myTank;

            #region 敌方子弹和我的坦克碰撞
            //如果敌方坦克的子弹不等于0,和我的坦克进行碰撞检测
            if (tempEnemyTankBullet.Count != 0 && myTank != null)
            {
                int removeEnemyTankBulletNum = 0;
                for (int i = 0; i < tempEnemyTankBullet.Count; i++)
                {
                    if (tempEnemyTankBullet[i].GetRectangle().IntersectsWith(tempMyTank.GetRectangle()))
                    {
                        //创建爆炸线程
                        ArrayList num = new ArrayList(2);
                        num.Add(tempEnemyTankBullet[i].X);
                        num.Add(tempEnemyTankBullet[i].Y);
                        Thread threadBlast = new Thread(new ParameterizedThreadStart(DrawBlast));
                        threadBlast.Start(num);
                        threadBlast.IsBackground = true;
                        // while (!threadBlast.IsAlive) ;

                        //移除碰撞的子弹和我的坦克
                        enemyTankBullet.RemoveAt(i - removeEnemyTankBulletNum);
                        removeEnemyTankBulletNum++;
                        myTank = null;
                    }
                }
            }
            #endregion

            //因为，我方子弹碰撞检测执行后，我方子弹数量可能发生变化，因此重新赋值
            tempMyTankBullet.Clear();
            foreach (Bullet temp in myTankBullet)
            {
                tempMyTankBullet.Add(temp);
            }
            #region 判断玩家子弹是否出界，出界就清除结点
            //如果我方子弹出界，那么清除它
            int removeBullet = 0;
            for (int i = 0; i < tempMyTankBullet.Count; i++)
            {
                if (tempMyTankBullet[i].X <= 0 || tempMyTankBullet[i].Y <= 0 || tempMyTankBullet[i].X >= screenWidth || tempMyTankBullet[i].Y >= screenHeight)
                {
                    myTankBullet.RemoveAt(i - removeBullet);
                    removeBullet++;
                }
            }
            #endregion

            //tempEnemyTankBullet需要重新赋值，因为上面的检测可能导致 enemyTankBullet的变化
            tempEnemyTankBullet.Clear();
            foreach (Bullet temp in enemyTankBullet)
            {
                tempEnemyTankBullet.Add(temp);
            }
            #region 判断敌方子弹是否出界，出界就清除结点
            //如果敌方子弹出界，那么清除它
            int removeEnemyTankBullet = 0;
            for (int i = 0; i < tempEnemyTankBullet.Count; i++)
            {
                if (tempEnemyTankBullet[i].X <= 0 || tempEnemyTankBullet[i].Y <= 0 || tempEnemyTankBullet[i].X >= screenWidth || tempEnemyTankBullet[i].Y >= screenHeight)
                {
                    enemyTankBullet.RemoveAt(i - removeEnemyTankBullet);
                    removeEnemyTankBullet++;
                }
            }
            #endregion


        }

        /// <summary>
        /// 画出游戏画面
        /// </summary>
        public void DrawMap()
        {
            try
            {
                Graphics g = this.CreateGraphics();
                g.DrawImage(bmp, 0, 0);
            }
            catch
            { }
        }

        #region 绘制我方坦克，敌方坦克，我方子弹，敌方子弹,绘制墙，绘制爆炸，绘制出生图片,绘制游戏结束

        public void DrawWall(Graphics g)
        {
            foreach (Wall tempWall in wall)
            {
                tempWall.Draw(g);
            }
            boss.Draw(g);
            foreach (Steel tempSteel in steel)
            {
                tempSteel.Draw(g);
            }
        }

        public void DrawMyTank(Graphics g)
        {
            if (myTank != null)
                myTank.Draw(g);
        }

        public void DrawEnemyTank(Graphics g)
        {
            List<EnemyTank> tempEnemyTank = new List<EnemyTank>();
            foreach (EnemyTank temp in enemyTank)
            {
                tempEnemyTank.Add(temp);
            }

            if (tempEnemyTank.Count != 0)
            {
                foreach (EnemyTank tem in tempEnemyTank)
                {
                    tem.Draw(g);
                }
            }
        }

        public void DrawMyTankBullet(Graphics g)
        {
            //绘制我方坦克的子弹
            if (myTankBullet.Count != 0)
            {
                for (int i = 0; i < myTankBullet.Count; i++)
                {
                    myTankBullet[i].Draw(g);
                }
            }
        }

        public void DrawEnemyTankBullet(Graphics g)
        {
            List<Bullet> tempEnemyTankBullet = new List<Bullet>();
            try
            {
                foreach (Bullet temp in enemyTankBullet)
                {
                    tempEnemyTankBullet.Add(temp);
                }
            }
            catch
            { 
            
            }
            //绘制敌方的子弹
            if (tempEnemyTankBullet.Count != 0)
            {
                foreach (Bullet tempenemyBullet in tempEnemyTankBullet)
                {
                    tempenemyBullet.Draw(g);
                }
            }
        }

        //绘制出生图片
        public void DrawBorn(int x, int y, int index)
        {
            gBorn = this.CreateGraphics();
            TankBorn myTankBorn = new TankBorn(x, y);
            myTankBorn.Draw(gBorn, index);
        }

        //爆炸方法
        public void DrawBlast(object obj)
        {
            ArrayList temp = (ArrayList)obj;
            Graphics tempGraphics = this.CreateGraphics();

            int x;
            int y;
            x = (int)temp[0];
            y = (int)temp[1];
            int index = 1;
            while (index <= 25)
            {
                Blast blast = new Blast(x, y);
                blast.Draw(tempGraphics, index / 5);
                index++;
            }
            Thread.CurrentThread.Abort();
        }

        //画出死亡的图片
        public void DrawGameOver(Graphics g)
        {
            threadEnemyTank.Abort();
            g.Clear(Color.Black);
            boss.DrawGameOver(g);

            //线程睡眠50毫秒是为了完成爆炸效果，因为爆炸效果新开线程做的，不在同一个线程。
            Thread.Sleep(50);
            DrawMap();
            threadRefresh.Abort();
        }

        #endregion

        /// <summary>
        /// 我方坦克的子弹移动
        /// </summary>
        public void MyTankBulletMethod()
        {
            // while (isRun)
            {
                if (myTankBullet.Count > 0)
                {
                    foreach (Bullet temp in myTankBullet)
                    {
                        temp.Move();
                    }
                }
                // Thread.Sleep(50);
            }
        }

        /// <summary>
        /// 敌方坦克的子弹移动
        /// </summary>
        public void EnemyTankBulletMethod()
        {
            //while (isRun)
            {
                if (enemyTank.Count > 0)
                {
                    foreach (Bullet temp in enemyTankBullet)
                    {
                        temp.Move();
                    }
                }
                //  Thread.Sleep(50);
            }
        }

        public void EnemyTankMethod()
        {
            while (isRun)
            {
                if (enemyTank.Count == 0 || enemyshowTimeIntervalCounter >= 50)
                {
                    Random rand = new Random();
                    if (enemyshowTimeIntervalCounter == 50)
                    {
                        int position = rand.Next(1, 4);
                        if (position == 1)
                        {
                            enemyTankBornPositonX = 0;
                            enemyTankBornPositonY = 0;
                        }
                        else if (position == 2)
                        {
                            enemyTankBornPositonX = 150;
                            enemyTankBornPositonY = 0;
                        }
                        else if (position == 3)
                        {
                            enemyTankBornPositonX = 300;
                            enemyTankBornPositonY = 0;
                        }
                    }

                    if (enemyTank.Count < enemyTankMaxNum)
                    {
                        int index = enemyTankBornPictureIndex / 2 + 1;
                        if (index <= 3)
                        {
                            DrawBorn(enemyTankBornPositonX, enemyTankBornPositonY, index);
                            enemyTankBornPictureIndex++;
                        }
                        else
                        {
                            enemyshowTimeIntervalCounter = 0;
                            enemyTankBornPictureIndex = 1;
                            enemyLife = rand.Next(1, 6);
                            if (enemyLife == 1)
                            {
                                int a = rand.Next(1, 3);
                                //坦克构造函数产生新坦克加入enemyTank链表
                                if (a == 1)
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Left);
                                    enemyTank.Add(tempEnemyTank);
                                }
                                else
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Right);
                                    enemyTank.Add(tempEnemyTank);
                                }
                            }
                            else if (enemyLife == 2)
                            {
                                int a = rand.Next(1, 3);
                                //坦克构造函数产生新坦克加入enemyTank链表
                                if (a == 1)
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed * 5, Direction.Left);
                                    enemyTank.Add(tempEnemyTank);
                                }
                                else
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed * 5, Direction.Right);
                                    enemyTank.Add(tempEnemyTank);
                                }
                            }
                            else if (enemyLife == 3)
                            {
                                int a = rand.Next(1, 3);
                                //坦克构造函数产生新坦克加入enemyTank链表
                                if (a == 1)
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Left);
                                    enemyTank.Add(tempEnemyTank);
                                }
                                else
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Right);
                                    enemyTank.Add(tempEnemyTank);
                                }
                            }
                            else if (enemyLife == 4)
                            {
                                int a = rand.Next(1, 3);
                                //坦克构造函数产生新坦克加入enemyTank链表
                                if (a == 1)
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Left);
                                    enemyTank.Add(tempEnemyTank);
                                }
                                else
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Right);
                                    enemyTank.Add(tempEnemyTank);
                                }
                            }
                            else if (enemyLife == 5)
                            {
                                int a = rand.Next(1, 3);
                                //坦克构造函数产生新坦克加入enemyTank链表
                                if (a == 1)
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Left);
                                    enemyTank.Add(tempEnemyTank);
                                }
                                else
                                {
                                    EnemyTank tempEnemyTank = new EnemyTank(enemyTankBornPositonX, enemyTankBornPositonY, enemyLife, enemyTankSpeed, Direction.Right);
                                    enemyTank.Add(tempEnemyTank);
                                }
                            }
                        }
                    }
                }
                enemyshowTimeIntervalCounter++;

                //为防止线程冲突，设置临时变量来保存
                List<Wall> tempWall = new List<Wall>();
                try
                {
                    foreach (Wall temp in wall)
                    {
                        tempWall.Add(temp);
                    }
                }
                catch
                { }

                MyTank tempMyTank = new MyTank(myTankBornPositionX, myTankBornPositionY, myTankLife, myTankSpeed, Direction.Up);
                tempMyTank = myTank;

                List<EnemyTank> temEnemyTank = new List<EnemyTank>();
                foreach (EnemyTank temp in enemyTank)
                {
                    temEnemyTank.Add(temp);
                }

                List<Steel> tempSteel = new List<Steel>();
                foreach (Steel temp in steel)
                {
                    tempSteel.Add(temp);
                }

                try
                {
                    foreach (EnemyTank temp in enemyTank)
                    {
                        if (enemyTank.Count != 0)
                        {
                            temp.Move(tempWall, tempSteel, tempMyTank, temEnemyTank, enemyTankWidth, enemyTankHeight, temp.Dir);
                        }
                    }
                    produceEnemyBulletCounter++;
                    if (produceEnemyBulletCounter % 10 == 1)
                    {
                        foreach (EnemyTank temp in enemyTank)
                        {
                            if (enemyTank.Count != 0)
                            {
                               // temp.Move(tempWall, tempSteel, tempMyTank, temEnemyTank, enemyTankWidth, enemyTankHeight, temp.Dir);

                                if (temp.Dir == Direction.Up)
                                {
                                    //构造函数，参数：横坐标，纵坐标，速度，方向，类型
                                    enemyTankBullet.Add(new Bullet(temp.X + 3, temp.Y - 4, enemyTankBulletSpeed, Direction.Up, BulletType.EnemyBullet));
                                }
                                else if (temp.Dir == Direction.Down)
                                {
                                    enemyTankBullet.Add(new Bullet(temp.X + 5, temp.Y + 13, enemyTankBulletSpeed, Direction.Down, BulletType.EnemyBullet));
                                }
                                else if (temp.Dir == Direction.Left)
                                {
                                    enemyTankBullet.Add(new Bullet(temp.X - 5, temp.Y + 5, enemyTankBulletSpeed, Direction.Left, BulletType.EnemyBullet));
                                }
                                else if (temp.Dir == Direction.Right)
                                {
                                    enemyTankBullet.Add(new Bullet(temp.X + 13, temp.Y + 3, enemyTankBulletSpeed, Direction.Right, BulletType.EnemyBullet));
                                }
                            }
                        }
                    }
                }
                catch
                { }
                Thread.Sleep(30);
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //窗口关闭前关闭线程
            try
            {
                //以缓和的方式关闭线程
                threadRefresh.Join(1);
                threadRefresh.Abort();
                threadEnemyTank.Join(1);
                threadEnemyTank.Abort();
            }
            catch
            {}
        }
    }
}


