﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

/*
 * 子弹类继承了基本元素类BaseElement
 * 子弹类是用于绘制我方坦克的子弹和地方坦克子弹的类
 * 子弹类通过枚举BulletType来确定，绘制我方坦克还是地方坦克
 * 子弹类的方法有构造方法和重写BaseElement类的Draw(Graphics g) 和 GetRectangel()的方法
 * 
 */
namespace Tank20120530
{
    //继承基本元素类
    class Bullet : Element
    {
        //子弹类型
        private BulletType bulletType;

        private Bitmap[] bulletBmp = new Bitmap[4]
        {
            Resources.BulletUp,
            Resources.BulletDown,
            Resources.BulletLeft,
            Resources.BulletRight
        };

        #region 访问器：子弹类型
        public BulletType _BulletType
        {
            get { return bulletType; }
            set { bulletType = value; }
        }
        #endregion

        //构造函数，参数：横坐标，纵坐标，速度，方向，类型
        public Bullet(int x, int y, int speed, Direction dir, BulletType bulletType)
            : base(x, y, dir, speed)
        {
            this.bulletType = bulletType;
        }

        //绘制子弹方法：通过bulletType来判断是我方的子弹还是敌方的子弹
        public override void Draw(Graphics g)
        {
            //画我方坦克
            //Bitmap tempBitmap = new Bitmap(Resources.bullet);
            if (this.Dir == Direction.Up)
            {
                bulletBmp[0].MakeTransparent(Color.White);
                g.DrawImage(bulletBmp[0], X, Y);
            }
            else if (this.Dir == Direction.Down)
            {
                bulletBmp[1].MakeTransparent(Color.White);
                g.DrawImage(bulletBmp[1], X, Y);
            }
            else if (this.Dir == Direction.Left)
            {
                bulletBmp[2].MakeTransparent(Color.White);
                g.DrawImage(bulletBmp[2], X, Y);
            }
            else if (this.Dir == Direction.Right)
            {
                bulletBmp[3].MakeTransparent(Color.White);
                g.DrawImage(bulletBmp[3], X, Y);
            }
        }

        //获取子弹图片矩形
        public override Rectangle GetRectangle()
        {
          //  if (this.bulletType == BulletType.MyBullet)
            {
                if (this.Dir == Direction.Up)
                {
                    return new Rectangle(this.X, this.Y, 10, bulletBmp[0].Height + this.Speed);
                }
                else if (this.Dir == Direction.Down)
                {
                    return new Rectangle(this.X, this.Y - this.Speed, 10, bulletBmp[0].Height);
                }
                else if (this.Dir == Direction.Left)
                {
                    return new Rectangle(this.X, this.Y, bulletBmp[0].Width + this.Speed, 10);
                }
                else
                {
                    return new Rectangle(this.X - this.Speed, this.Y, bulletBmp[0].Width, 10);
                }
            }
            //else
            //{
            //    if (this.Dir == Direction.Up)
            //    {
            //        return new Rectangle(this.X, this.Y, bulletBmp[0].Width, bulletBmp[0].Height + this.Speed);
            //    }
            //    else if (this.Dir == Direction.Down)
            //    {
            //        return new Rectangle(this.X, this.Y, bulletBmp[0].Width, bulletBmp[0].Height + this.Speed);
            //    }
            //    else if (this.Dir == Direction.Left)
            //    {
            //        return new Rectangle(this.X, this.Y, bulletBmp[0].Width + this.Speed, bulletBmp[0].Height);
            //    }
            //    else
            //    {
            //        return new Rectangle(this.X, this.Y, bulletBmp[0].Width + this.Speed, bulletBmp[0].Height);
            //    }
            //}
        }

        //子弹的移动
        public void Move()
        {
            if (this.Dir == Direction.Up)
            {
                this.Y -= this.Speed;
            }
            else if (this.Dir == Direction.Down)
            {
                this.Y += this.Speed;
            }
            else if (this.Dir == Direction.Left)
            {
                this.X -= this.Speed;
            }
            else
            {
                this.X += this.Speed;
            }
        }

    }
}
