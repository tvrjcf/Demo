﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

namespace Tank20120530
{
    class Boss: Coordination
    {
        //构造函数
        public Boss(int x, int y)
            : base(x, y)
        {
        }

        //画墙函数
        public void Draw(Graphics g)
        {
            g.DrawImage(Resources.Boss, X, Y,30,30);
        }

        //获得图片的矩形
        public Rectangle GetRectangle()
        {
            return new Rectangle(this.X, this.Y, 30, 30);
        }

        public void DrawGameOver(Graphics g)
        {
            g.DrawImage(Resources.GameOver, 0, 0,390,390);
        }
    }
}
