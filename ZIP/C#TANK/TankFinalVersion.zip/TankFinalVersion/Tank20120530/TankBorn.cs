﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

namespace Tank20120530
{
    class TankBorn : Coordination
    {
        private Bitmap[] bornBitmap = new Bitmap[]
        {
        Resources.Star1,
        Resources.Star2,
        Resources.Star3
        };

        public TankBorn(int x, int y)
            : base(x, y)
        {
        }

        public void Draw(Graphics g, int i)
        {
            if (i == 1)
            {
                bornBitmap[0].MakeTransparent(Color.Black); 
                g.DrawImage(bornBitmap[0], X, Y);
            }
            else if (i == 2)
            {
                bornBitmap[1].MakeTransparent(Color.Black);
                g.DrawImage(bornBitmap[1], X, Y);
            }
            else if (i == 3)
            {
                bornBitmap[2].MakeTransparent(Color.Black);
                g.DrawImage(bornBitmap[2], X, Y);
            }
        }
    }
}
