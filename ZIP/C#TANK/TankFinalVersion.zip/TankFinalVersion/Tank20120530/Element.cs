﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Tank20120530
{
    /// <summary>
    /// 坦克的基本元素类
    /// </summary>
    abstract class Element : Coordination
    {
        private Direction dir;
        private int speed;

        //带参数构造函数坐标，生命，速度，上下左右，图片
        public Element(int x, int y, Direction dir, int speed)
            : base(x, y)
        {
            this.dir = dir;
            this.speed = speed;
        }

        //抽象的画图函数
        public abstract void Draw(Graphics g);

        //获得图片矩形，在碰撞检测时可以通过两个图片矩形是否相交来检测是否碰撞
        public abstract Rectangle GetRectangle();


        #region 私有变量访问器 x,y,dir,speed
        public Direction Dir
        {
            get { return dir; }
            set { dir = value; }
        }
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        #endregion
    }
}
