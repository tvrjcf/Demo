﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

namespace Tank20120530
{
    class Steel : Coordination
    {
        //构造函数
        public Steel(int x, int y)
            : base(x, y)
        {
        }

        //画墙函数
        public void Draw(Graphics g)
        {
            g.DrawImage(Resources.steel, X, Y,15,15);
        }

        //获得图片的矩形
        public Rectangle GetRectangle()
        {
            return new Rectangle(this.X, this.Y, 15, 15);
        }
    }
}
