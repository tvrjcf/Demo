﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tank20120530
{
    //枚举坦克的种类：我的坦克，敌人的坦克
    public enum TankType
    {
        MyTank = 1,
        EnemyTank = 2
    }
}
