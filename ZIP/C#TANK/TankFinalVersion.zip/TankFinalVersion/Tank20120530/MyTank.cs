﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tank20120530.Properties;
using System.Drawing;
/*
 * Tank类是绘制我方坦克和敌方坦克的类。
 * 组成元素有：继承于基本元素类BaseElement的横坐标x,总坐标y,枚举的方向dir;
 *             坦克的生命，坦克的速度，以及枚举的坦克类型（用来区分是绘制我的坦克还是敌方坦克）
 * Tank类的方法有重写BaseElement类的Draw（Graphics g）,GetRectangle()方法以及带参数的构造方法和TankMove方法
 */
namespace Tank20120530
{
    //继承基本元素类的坦克类
    class MyTank : Element
    {
        private int life;
        //获取我的坦克和敌人的坦克的位图(顺序分别为上下左右)
        private Bitmap[] myTankBitmap = new Bitmap[4]
            {
               Resources.MyTankUp,
               Resources.MyTankDown,
               Resources.MyTankLeft,
               Resources.MyTankRight
            };

        #region 访问器:生命
        public int Life
        {
            get { return life; }
            set { life = value; }
        }
        #endregion

        //构造函数，参数：横坐标，纵坐标，生命,速度，方向，坦克类型
        public MyTank(int x, int y, int life, int speed, Direction dir)
            : base(x, y, dir, speed)
        {
            this.life = life;
        }

        /// <summary>
        /// 画我方坦克
        /// </summary>
        /// <param name="g"></param>
        public override void Draw(Graphics g)
        {
            //绘制我方坦克
            if (this.Dir == Direction.Up)
            {
                Bitmap temp = new Bitmap(myTankBitmap[0]);
                temp.MakeTransparent(temp.GetPixel(0, 0));
                g.DrawImage(temp, X, Y);
            }
            else if (this.Dir == Direction.Down)
            {
                Bitmap temp = new Bitmap(myTankBitmap[1]);
                temp.MakeTransparent(temp.GetPixel(0, 0));
                g.DrawImage(temp, X, Y);
            }
            else if (this.Dir == Direction.Left)
            {
                Bitmap temp = new Bitmap(myTankBitmap[2]);
                temp.MakeTransparent(temp.GetPixel(0, 0));
                g.DrawImage(temp, X, Y);
            }
            else if (this.Dir == Direction.Right)
            {
                Bitmap temp = new Bitmap(myTankBitmap[3]);
                temp.MakeTransparent(temp.GetPixel(0, 0));
                g.DrawImage(temp, X, Y);
            }
        }

        /// <summary>
        /// 获取图片矩形
        /// </summary>
        public override Rectangle GetRectangle()
        {
            if (this.Dir == Direction.Up)
            {
                return new Rectangle(this.X, this.Y - this.Speed, 26, 26);
            }
            else if (this.Dir == Direction.Down)
            {
                return new Rectangle(this.X, this.Y + this.Speed, 26, 26);
            }
            else if (this.Dir == Direction.Left)
            {
                return new Rectangle(this.X - this.Speed, this.Y, 26, 26);
            }
            else
            {
                return new Rectangle(this.X, this.Y + this.Speed, 26, 26);
            }
        }

        /// <summary>
        /// 坦克移动
        /// </summary>
        /// <param name="wall">wall 是墙</param>
        /// e1是我方坦克
        /// width 表示元素的宽度
        /// height表示元素的高度
        public void Move(List<Wall> wall, List<Steel> steel, MyTank myTank, List<EnemyTank> enemyTank, int width, int height, Direction direction)
        {
            #region 玩家坦克
            //如果是我方坦克的移动
            if (myTank != null)
            {
                bool canMove = true;
                Rectangle rect;
                if (direction == Direction.Up)
                {
                    rect = new Rectangle(X, Y - Speed, width, height);
                    if (Y <= 0)
                        canMove = false;
                }
                else if (direction == Direction.Down)
                {
                    rect = new Rectangle(X, Y + Speed, width, height);
                    if (Y + 30 >= 390)
                        canMove = false;
                }
                else if (direction == Direction.Left)
                {
                    rect = new Rectangle(X - Speed, Y, width, height);
                    if (X <= 0)
                    {
                        canMove = false;
                    }

                }
                else
                {
                    rect = new Rectangle(X + Speed, Y, width, height);
                    if (X + 30 >= 390)
                    {
                        canMove = false;
                    }
                }

                foreach (Wall tempWall in wall)
                {
                    if (tempWall.GetRectangle().IntersectsWith(rect))
                        canMove = false;
                }

                foreach (Steel tempSteel in steel)
                {
                    if (tempSteel.GetRectangle().IntersectsWith(rect))
                        canMove = false;
                }

                //检测当前坦克和敌方坦克是否会碰撞
                foreach (EnemyTank tempEnemyTank in enemyTank)
                {
                    if (tempEnemyTank.GetRectangle().IntersectsWith(rect))
                        canMove = false;
                }
                if (canMove == true)
                {
                   // Dir = direction;
                    if (direction == Direction.Up)
                    {
                        Y = Y - Speed;
                    }
                    else if (direction == Direction.Down)
                    {
                        Y = Y + Speed;
                    }
                    else if (direction == Direction.Left)
                    {
                        X = X - Speed;
                    }
                    else
                    {
                        X = X + Speed;
                    }
                }
                Dir = direction;
            }
            #endregion
        }
    }
}

