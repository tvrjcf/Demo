﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

namespace Tank20120530
{
    class EnemyTank : Element
    {
        private int life;

        //此处生命为5的时候显示绿色的坦克，如果生命为4的时候坦克变为黄色，生命为3的话为灰色，生命为2的话为快速，生命为1的为低速坦克
        private Bitmap[] slowEnemyTankBitmap = new Bitmap[4]
            {
                Resources.SlowUp,
                Resources.SlowDown,
                Resources.SlowLeft,
                Resources.SlowRight
            };
        private Bitmap[] quickEnemyTankBitmap = new Bitmap[4]
            {
                Resources.QuickUp,
                Resources.QuickDown,
                Resources.QuickLeft,
                Resources.QuickRight
            };
        private Bitmap[] greenEnemyTankBitmap = new Bitmap[4]
        {
        Resources.GreenUp,
        Resources.GreenDown,
        Resources.GreenLeft,
        Resources.GreenRight
        };
        private Bitmap[] yellowEnemyTankBitmap = new Bitmap[4]
        {
        Resources.YellowUp,
        Resources.YellowDown,
        Resources.YellowLeft,
        Resources.YellowRight
        };
        private Bitmap[] grayEnemyTankBitmap = new Bitmap[4]
        {
        Resources.GreenUp,
        Resources.GreenDown,
        Resources.GrayLeft,
        Resources.GrayRight
        };



        #region 访问器:生命
        public int Life
        {
            get { return life; }
            set { life = value; }
        }
        #endregion

        //构造函数，参数：横坐标，纵坐标，生命,速度，方向
        public EnemyTank(int x, int y, int life, int speed, Direction dir)
            : base(x, y, dir, speed)
        {
            this.life = life;
        }
        /// <summary>
        /// 根据坦克的种类tankType来判断究竟是画我方坦克还是地方坦克
        /// </summary>
        /// <param name="g"></param>
        public override void Draw(Graphics g)
        {
            //绘制敌方坦克
            if (this.Dir == Direction.Up)
            {
                if (life == 1)
                {
                    Bitmap temp = new Bitmap(slowEnemyTankBitmap[0]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 2)
                {
                    Bitmap temp = new Bitmap(quickEnemyTankBitmap[0]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 3)
                {
                    Bitmap temp = new Bitmap(grayEnemyTankBitmap[0]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 4)
                {
                    Bitmap temp = new Bitmap(yellowEnemyTankBitmap[0]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if(life == 5)
                {
                    Bitmap temp = new Bitmap(greenEnemyTankBitmap[0]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
            }
            else if (this.Dir == Direction.Down)
            {
                if (life == 1)
                {
                    Bitmap temp = new Bitmap(slowEnemyTankBitmap[1]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 2)
                {
                    Bitmap temp = new Bitmap(quickEnemyTankBitmap[1]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 3)
                {
                    Bitmap temp = new Bitmap(grayEnemyTankBitmap[1]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 4)
                {
                    Bitmap temp = new Bitmap(yellowEnemyTankBitmap[1]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 5)
                {
                    Bitmap temp = new Bitmap(greenEnemyTankBitmap[1]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
            }
            else if (this.Dir == Direction.Left)
            {
                if (life == 1)
                {
                    Bitmap temp = new Bitmap(slowEnemyTankBitmap[2]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 2)
                {
                    Bitmap temp = new Bitmap(quickEnemyTankBitmap[2]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 3)
                {
                    Bitmap temp = new Bitmap(grayEnemyTankBitmap[2]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 4)
                {
                    Bitmap temp = new Bitmap(yellowEnemyTankBitmap[2]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 5)
                {
                    Bitmap temp = new Bitmap(greenEnemyTankBitmap[2]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
            }
            else if (this.Dir == Direction.Right)
            {
                if (life == 1)
                {
                    Bitmap temp = new Bitmap(slowEnemyTankBitmap[3]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 2)
                {
                    Bitmap temp = new Bitmap(quickEnemyTankBitmap[3]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 3)
                {
                    Bitmap temp = new Bitmap(grayEnemyTankBitmap[3]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 4)
                {
                    Bitmap temp = new Bitmap(yellowEnemyTankBitmap[3]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
                else if (life == 5)
                {
                    Bitmap temp = new Bitmap(greenEnemyTankBitmap[3]);
                    temp.MakeTransparent(temp.GetPixel(0, 0));
                    g.DrawImage(temp, X, Y);
                }
            }
        }

        /// <summary>
        /// 获取图片矩形
        /// </summary>
        public override Rectangle GetRectangle()
        {
            if (life == 1)
            {
                if (this.Dir == Direction.Up)
                {
                    return new Rectangle(this.X, this.Y - this.Speed, 26, 26);
                }
                else if (this.Dir == Direction.Down)
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 26, 26);
                }
                else if (this.Dir == Direction.Left)
                {
                    return new Rectangle(this.X - this.Speed, this.Y, 26, 26);
                }
                else
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 26, 26);
                }
            }
            else if (life == 2)
            {
                if (this.Dir == Direction.Up)
                {
                    return new Rectangle(this.X, this.Y - this.Speed, 24, 28);
                }
                else if (this.Dir == Direction.Down)
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 24, 28);
                }
                else if (this.Dir == Direction.Left)
                {
                    return new Rectangle(this.X - this.Speed, this.Y, 28, 24);
                }
                else
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 28, 24);
                }
            }
            else if (life == 3)
            {
                if (this.Dir == Direction.Up)
                {
                    return new Rectangle(this.X, this.Y - this.Speed, 26, 28);
                }
                else if (this.Dir == Direction.Down)
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 26, 28);
                }
                else if (this.Dir == Direction.Left)
                {
                    return new Rectangle(this.X - this.Speed, this.Y, 28, 26);
                }
                else
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 28, 26);
                }
            }
            else if (life == 4)
            {
                if (this.Dir == Direction.Up)
                {
                    return new Rectangle(this.X, this.Y - this.Speed, 26, 28);
                }
                else if (this.Dir == Direction.Down)
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 26, 28);
                }
                else if (this.Dir == Direction.Left)
                {
                    return new Rectangle(this.X - this.Speed, this.Y, 28, 26);
                }
                else
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 28, 26);
                }
            }
            else 
            {
                if (this.Dir == Direction.Up)
                {
                    return new Rectangle(this.X, this.Y - this.Speed, 26, 28);
                }
                else if (this.Dir == Direction.Down)
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 26, 28);
                }
                else if (this.Dir == Direction.Left)
                {
                    return new Rectangle(this.X - this.Speed, this.Y, 28, 26);
                }
                else
                {
                    return new Rectangle(this.X, this.Y + this.Speed, 28, 26);
                }
            }
        }

        /// <summary>
        /// 坦克移动
        /// </summary>
        /// <param name="wall">wall 是墙</param>
        /// 
        /// width 表示元素的宽度
        /// height表示元素的高度
        public void Move(List<Wall> wall, List<Steel> steel, MyTank myTank, List<EnemyTank> enemyTank, int width, int height, Direction direction)
        {
            //如果是敌方坦克的移动
            if (myTank != null)
            {
                bool canMoveUp = true;
                bool canMoveDown = true;
                bool canMoveLeft = true;
                bool canMoveRight = true;

                if (X <= 0)
                {
                    canMoveLeft = false;
                }
                if (X >= 390 - 30)
                {
                    canMoveRight = false;
                }
                if (Y <= 0)
                {
                    canMoveUp = false;
                }
                if (Y >= 390 - 30)
                {
                    canMoveDown = false;
                }
                Rectangle rect;
                rect = new Rectangle(X, Y, width, height);

               // bool isCollison = false;
                //检测当前坦克和敌方坦克是否会碰撞
                //foreach (EnemyTank tempEnemyTank in enemyTank)
                //{
                //    if ((tempEnemyTank.X != this.X) && (tempEnemyTank.Y != this.Y))
                //    {

                //        if (tempEnemyTank.GetRectangle().IntersectsWith(rect))
                //        {
                //            if (direction == Direction.Up)
                //            {
                //                //canMoveDown = true;
                //                Dir = Direction.Down;
                //            }
                //            else if (direction == Direction.Down)
                //            {
                //               // canMoveUp = true;
                //                Dir = Direction.Up;
                //            }
                //            else if (direction == Direction.Left)
                //            {
                //              //  canMoveRight = true;
                //                Dir = Direction.Right;
                //            }
                //            else
                //            {
                //                //canMoveLeft = true;
                //                Dir = Direction.Left;
                //            }
                //            //isCollison = true;
                //            break;
                //        }
                //    }
                //}

               // if (isCollison == false)
                {
                    Rectangle rectUp, rectDown, rectLeft, rectRight;
                    rectUp = new Rectangle(X, Y - Speed, width, height);
                    rectDown = new Rectangle(X, Y + Speed, width, height);
                    rectLeft = new Rectangle(X - Speed, Y, width, height);
                    rectRight = new Rectangle(X + Speed, Y, width, height);

                    ////检测当前坦克和敌方坦克是否会碰撞
                    //foreach (EnemyTank tempEnemyTank in enemyTank)
                    //{
                    //    if ((tempEnemyTank.X != this.X) && (tempEnemyTank.Y != this.Y))
                    //    {
                    //        if (canMoveUp)
                    //        {
                    //            if (tempEnemyTank.GetRectangle().IntersectsWith(rectUp))
                    //                canMoveUp = false;
                    //        }
                    //        if (canMoveDown)
                    //        {
                    //            if (tempEnemyTank.GetRectangle().IntersectsWith(rectDown))
                    //                canMoveDown = false;
                    //        }
                    //        if (canMoveLeft)
                    //        {
                    //            if (tempEnemyTank.GetRectangle().IntersectsWith(rectLeft))
                    //                canMoveLeft = false;
                    //        }
                    //        if (canMoveRight)
                    //        {
                    //            if (tempEnemyTank.GetRectangle().IntersectsWith(rectRight))
                    //                canMoveRight = false;
                    //        }
                    //    }
                    //}


                    //检测当前坦克和钢铁是否会碰撞
                    foreach (Steel tempSteel in steel)
                    {
                        if (canMoveUp)
                        {
                            if (tempSteel.GetRectangle().IntersectsWith(rectUp))
                                canMoveUp = false;
                        }
                        if (canMoveDown)
                        {
                            if (tempSteel.GetRectangle().IntersectsWith(rectDown))
                                canMoveDown = false;
                        }
                        if (canMoveLeft)
                        {
                            if (tempSteel.GetRectangle().IntersectsWith(rectLeft))
                                canMoveLeft = false;
                        }
                        if (canMoveRight)
                        {
                            if (tempSteel.GetRectangle().IntersectsWith(rectRight))
                                canMoveRight = false;
                        }
                    }
                    //检测是否和我方坦克碰撞
                    if (canMoveUp)
                    {
                        if (myTank.GetRectangle().IntersectsWith(rectUp))
                        {
                            canMoveUp = false;
                        }
                    }
                    if (canMoveDown)
                    {
                        if (myTank.GetRectangle().IntersectsWith(rectDown))
                        {
                            canMoveDown = false;
                        }
                    }
                    if (canMoveLeft)
                    {
                        if (myTank.GetRectangle().IntersectsWith(rectLeft))
                        {
                            canMoveLeft = false;
                        }
                    }
                    if (canMoveRight)
                    {
                        if (myTank.GetRectangle().IntersectsWith(rectRight))
                        {
                            canMoveRight = false;
                        }
                    }

                    //检测当前坦克和墙是否会碰撞
                    foreach (Wall tempWall in wall)
                    {
                        if (canMoveUp)
                        {
                            if (tempWall.GetRectangle().IntersectsWith(rectUp))
                                canMoveUp = false;
                        }
                        if (canMoveDown)
                        {
                            if (tempWall.GetRectangle().IntersectsWith(rectDown))
                                canMoveDown = false;
                        }
                        if (canMoveLeft)
                        {
                            if (tempWall.GetRectangle().IntersectsWith(rectLeft))
                                canMoveLeft = false;
                        }
                        if (canMoveRight)
                        {
                            if (tempWall.GetRectangle().IntersectsWith(rectRight))
                                canMoveRight = false;
                        }
                    }
                }


                if (Dir == Direction.Up && canMoveUp == true)
                {
                    Dir = Direction.Up;
                    Y = Y - Speed;
                }
                else if (Dir == Direction.Down && canMoveDown == true)
                {
                    Dir = Direction.Down;
                    Y = Y + Speed;
                }
                else if (Dir == Direction.Left && canMoveLeft == true)
                {
                    Dir = Direction.Left;
                    X = X - Speed;
                }
                else if (Dir == Direction.Right && canMoveRight == true)
                {
                    Dir = Direction.Right;
                    X = X + Speed;
                }
                else
                {
                    if (Dir == Direction.Left && canMoveDown == true)
                    {
                        Dir = Direction.Down;
                    }
                    else if (Dir == Direction.Left && canMoveRight == true)
                    {
                        Dir = Direction.Right;
                    }
                    else if (Dir == Direction.Right && canMoveDown == true)
                    {
                        Dir = Direction.Down;
                    }
                    else if (Dir == Direction.Right && canMoveLeft == true)
                    {
                        Dir = Direction.Left;
                    }
                    else if (Dir == Direction.Down && canMoveLeft == true)
                    {
                        Dir = Direction.Left;
                    }
                    else if (Dir == Direction.Down && canMoveRight == true)
                    {
                        Dir = Direction.Right;
                    }
                }
            }
        }
    }
}
