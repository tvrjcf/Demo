﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tank20120530
{
    /// <summary>
    /// 枚举方向
    /// </summary>
    public enum Direction
    {
        Up = 1,
        Down = 2,
        Left = 3,
        Right = 4
    }
}
