﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tank20120530
{
    //枚举子弹的种类：我的子弹，敌人的子弹
    public enum BulletType
    {
        MyBullet,
        EnemyBullet
    }
}
