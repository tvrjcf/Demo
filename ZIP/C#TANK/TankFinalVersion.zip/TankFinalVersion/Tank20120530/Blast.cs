﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

namespace Tank20120530
{
    class Blast : Coordination
    {
        private Bitmap[] blastBitmap = new Bitmap[]
        {
        Resources.EXP1,
        Resources.EXP2,
        Resources.EXP3,
        Resources.EXP4,
        Resources.EXP5
        };

        public Blast(int x, int y)
            : base(x, y)
        {
        }

        public void Draw(Graphics g, int i)
        {
            if (i == 1)
            {
                blastBitmap[0].MakeTransparent(Color.Black); 
                g.DrawImage(blastBitmap[0], X, Y);
            }
            else if (i == 2)
            {
                blastBitmap[1].MakeTransparent(Color.Black);
                g.DrawImage(blastBitmap[1], X, Y);
            }
            else if (i == 3)
            {
                blastBitmap[2].MakeTransparent(Color.Black);
                g.DrawImage(blastBitmap[2], X, Y);
            }
            else if (i == 4)
            {
                blastBitmap[3].MakeTransparent(Color.Black);
                g.DrawImage(blastBitmap[3], X, Y);
            }
            else if (i == 5)
            {
                blastBitmap[4].MakeTransparent(Color.Black);
                g.DrawImage(blastBitmap[4], X, Y);
            }
        }

    }
}
