﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tank20120530
{
    class Coordination
    {
        //坐标,方向，速度（这些是坦克和子弹的共同特征）
        private int x;
        private int y;
        public Coordination(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }
    }
}
