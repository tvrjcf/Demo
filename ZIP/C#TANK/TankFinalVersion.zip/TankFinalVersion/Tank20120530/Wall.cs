﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Tank20120530.Properties;

namespace Tank20120530
{
    class Wall : Coordination
    {
        //构造函数
        public Wall(int x, int y)
            : base(x, y)
        {
        }

        //画墙函数
        public void Draw(Graphics g)
        {
            g.DrawImage(Resources.wall, X, Y);
        }

        //获得图片的矩形
        public Rectangle GetRectangle()
        {
            //return new Rectangle(this.X, this.Y, Resources.wall.Width, Resources.wall.Height);
            return new Rectangle(this.X, this.Y, 15, 15);
        }
    }
}
